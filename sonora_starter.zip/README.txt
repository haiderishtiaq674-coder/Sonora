SONORA starter
1) Upload index.html to your GitHub repository (Add file > Upload files).
2) For a public web app, open Settings > Pages, choose Deploy from a branch, select main and / (root), then Save.
3) Wait for GitHub Pages to publish. Open the displayed URL on Android or iPhone.
This starter currently offers an aesthetic interface and opens YouTube search. It does not yet provide automated API search or an embedded song catalog; those require a secured API integration and further work.
